﻿//PROG1224
//Lab 8 Exercise
// Umar Kamalitdinov

using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;

namespace Lab8
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private Dictionary<int, Item> items = new Dictionary<int, Item>();

        private void SubmitClick(object sender, RoutedEventArgs e)
        {
            // Get values from the input
            try
            {
                DateTime date = dpItem.Date.DateTime;
                string description = txtItemDescription.Text;
                decimal amount = Decimal.Parse(txtItemAmount.Text);

                // Create and add the new item
                Item newItem = new Item(date, description, amount);
                items.Add(newItem.ID, newItem);

                // Successful addition output
                txtOutput.Text = "Item was successfully added.";
            }
            catch (FormatException)
            {
                txtOutput.Text = "Invalid input format. Please check the date and amount.";
            }
            catch (ArgumentNullException ex)
            {
                txtOutput.Text = ex.Message;
            }
            catch (Exception ex)
            {
                txtOutput.Text += "An error occured: " + ex.ToString();
            }
        }

        private void IDKeyDown(object sender, KeyRoutedEventArgs e)
        {
            // User hits the enter key after entering ID number
            // to locate an Item
            if(e.Key== Windows.System.VirtualKey.Enter)
            {
                try
                {
                    int id = int.Parse(txtID.Text);
                    if (items.ContainsKey(id))
                    {
                        txtOutput.Text = items[id].ToString();
                    }
                    else
                    {
                        txtOutput.Text = "Items with ID " + id + " does not exist.";
                    }
                }
                catch (FormatException)
                {
                    txtOutput.Text = "Invalid ID format. Please enter a valid integer.";
                }
                catch (Exception ex)
                {
                    txtOutput.Text = "An error occurred: " + ex.Message;
                }
            }
        }
    }
}
