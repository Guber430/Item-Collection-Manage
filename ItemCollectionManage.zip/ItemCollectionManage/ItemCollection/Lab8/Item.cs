﻿//PROG1224
//Lab 8 Exercise
// Umar Kamalitdinov

using System;

namespace Lab8
{
    // class to represent Item for sale
    internal class Item
    {
        // instance fields
        private int id;
        private DateTime? date;
        private string description;
        private decimal amount;

        // class field for generating unique id numbers
        private static int count = 0;

        // constructor date and description required
        // amount must be a positive number
        // id is auto incremented by one
        public Item(DateTime? date, string description, decimal amount)
        {
            this.date = date ?? throw new ArgumentNullException("Date Required");
            this.description = string.IsNullOrEmpty(description) ? throw new ArgumentNullException("Description Required") : description;
            this.amount = Math.Abs(amount);
            this.id = ++count;
        }

        // read only ID properties
        public int ID => this.id;
        public string Description => $"{this.ID}: {this.description}";
        public decimal Amount => this.amount;

        // ToString Item output
        public override string ToString()
            => $"Item {ID} {date.Value.ToShortDateString()} :" +
                $" {date.Value.ToShortTimeString()}" +
                $"\n{description}\n{amount.ToString("C2")}";
    }
}
